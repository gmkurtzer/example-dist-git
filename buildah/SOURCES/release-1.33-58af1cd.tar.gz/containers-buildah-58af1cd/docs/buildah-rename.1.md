# buildah-rename "1" "July 2018" "buildah"

## NAME
buildah\-rename - Rename a local container.

## SYNOPSIS
**buildah rename** *container* *new-name*

## DESCRIPTION
Rename a local container.

## EXAMPLE

buildah rename containerName NewName

buildah rename containerID NewName

## SEE ALSO
buildah(1)
